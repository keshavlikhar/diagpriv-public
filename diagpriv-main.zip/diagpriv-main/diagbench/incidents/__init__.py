"""Canonical synthetic incident fixtures."""

